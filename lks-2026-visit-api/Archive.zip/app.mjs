import { Hono } from "hono";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, ScanCommand } from "@aws-sdk/lib-dynamodb";

const COUNT_TABLE_NAME = process.env.COUNT_TABLE_NAME || "lks-2026-visit-count";

const dynamo = DynamoDBDocumentClient.from(new DynamoDBClient({}));

const app = new Hono();

app.get("/", (c) => {
  return c.json({ message: "Hello from lks-2026-visit-api" });
});

app.get("/visit-count", async (c) => {
  const items = [];
  let lastKey;

  do {
    const result = await dynamo.send(
      new ScanCommand({
        TableName: COUNT_TABLE_NAME,
        ExclusiveStartKey: lastKey,
      })
    );
    items.push(...(result.Items ?? []));
    lastKey = result.LastEvaluatedKey;
  } while (lastKey);

  return c.json(items);
});

export default app;